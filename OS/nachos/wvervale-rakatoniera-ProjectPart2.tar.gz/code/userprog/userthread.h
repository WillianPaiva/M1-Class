
#ifndef USERTHREAD_H
#define USERTHREAD_H

extern int do_ThreadCreate(int f, int arg);
static void StartUserThread(void *schmurtz);
extern int do_ThreadExit();
#endif 
