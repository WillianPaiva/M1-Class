package enviroment;

import java.util.Map;
import sun.security.pkcs11.wrapper.Functions;

public class ClassType {
    int size;
    String classType;
    Env env;

	/**
	 *
	 */
    public ClassType(int size, String classType,Env env) {
        this.size = size;
        this.classType = classType;
        this.env = env;
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * @return the classType
	 */
	public String getClassType() {
		return classType;
	}

	/**
	 * @param classType the classType to set
	 */
	public void setClassType(String classType) {
		this.classType = classType;
	}



	/**
	 * @return the env
	 */
	public Env getEnv() {
		return env;
	}

	/**
	 * @param env the env to set
	 */
	public void setEnv(Env env) {
		this.env = env;
	}

    public String toString() {
        return env.toString();
    }
}
