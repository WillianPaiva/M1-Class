package ecomerce.procducts;

public interface CatalogAdiminItf {
    public int addProductInCatalog(Product p);
    public void removeProductInCatalog(int productId);
}
