package ecomerce.procducts;

public enum ProductType {
    Book,
    CD,
    Game
}
