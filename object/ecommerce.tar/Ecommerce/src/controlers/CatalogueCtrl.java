package controlers;

public class CatalogueCtrl {
}